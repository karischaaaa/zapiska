var HideShowFieldsByCheckbox = function() 
{
    // Находим поле 1 по data-name (название поля на просмотре)
    var field1 = $("div[data-name='Поле 1']");	
    
    // Находим чекбокс Поле 2 по data-name
    var checkboxContainer = $("div[data-name='Поле 2']");
    var checkbox = checkboxContainer.find("input[type='checkbox']");

    if ($(checkbox).prop("checked")) // если чекбокс установлен
    {	
        showViewElementColumn(field1);	// показываем Поле 1
    } 
    else 
    {
        hideViewElementColumn(field1);	// скрываем Поле 1
    }
}

// Вызываем функцию при загрузке страницы
$(document).ready(function() {
    HideShowFieldsByCheckbox();
});